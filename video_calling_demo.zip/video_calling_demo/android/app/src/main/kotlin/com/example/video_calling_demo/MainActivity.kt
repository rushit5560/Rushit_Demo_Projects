package com.example.video_calling_demo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

import 'dart:developer';
import 'package:agora_rtc_engine/rtc_engine.dart';
import 'package:flutter/material.dart';
import 'package:agora_rtc_engine/rtc_local_view.dart' as RtcLocalView;
import 'package:agora_rtc_engine/rtc_remote_view.dart' as RtcRemoteView;

class CallScreen extends StatefulWidget {
  final String channelName;
  const CallScreen({Key? key, required this.channelName}) : super(key: key);

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {

  late RtcEngine _engine;
  bool isLoading = false;
  String appId = "ba72fba67b13486e9799811e277931eb";
  List remoteUids = [];
  double xPosition = 0;
  double yPosition = 0;

  @override
  void initState() {
    super.initState();
    initializeAgora();
  }

  @override
  void dispose() {
   _engine.destroy();
    super.dispose();
  }


  Future<void> initializeAgora() async {
    setState(() => isLoading = true );
    _engine = await RtcEngine.createWithContext(RtcEngineContext(appId));
    await _engine.enableVideo();
    await _engine.setChannelProfile(ChannelProfile.Communication);
    _engine.setEventHandler(RtcEngineEventHandler(
      joinChannelSuccess: (channel, uid, elapsed) {
        log('Channel joined');
      },
      userJoined: (uid, elapsed) {
        log('userJoined :$uid');
        setState(() {
          remoteUids.add(uid);
        });
      },
      userOffline: (uid, elapsed) {
        log('userOffline :$uid');
        setState(() {
          remoteUids.remove(uid);
        });
      }
    ));

    await _engine.joinChannel(null, widget.channelName, null, 0).then((value) {
      setState(() => isLoading = false );
    });
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:(isLoading) ?
          const Center(child: CircularProgressIndicator())
      : Stack(
        children: [

          Center(
            child: renderRemoteView(),
          ),

          Positioned(
            top: yPosition,
            left: xPosition,
            child: GestureDetector(
              onPanUpdate: (tapInfo) {
                setState(() {
                  xPosition += tapInfo.delta.dx;
                  yPosition += tapInfo.delta.dy;
                });
              },

              child: const SizedBox(
                  width: 100,
                  height: 130,
                  child: RtcLocalView.SurfaceView()),
            ),
          ),
        ],
      ),
    );
  }

  Widget renderRemoteView() {
    if(remoteUids.isNotEmpty) {
      if(remoteUids.length == 1) {
        // return RtcRemoteView.SurfaceView(uid: remoteUids[0], channelId: widget.channelName,);
        return SizedBox(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 200,
              childAspectRatio: 11/20,
              crossAxisSpacing: 5,
              mainAxisSpacing: 10,
            ),
            itemCount: remoteUids.length,
            itemBuilder: (context, i) {
              return Container(
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: Colors.amber,
                ),
                child: RtcRemoteView.SurfaceView(uid: remoteUids[i], channelId: widget.channelName),
              );
            },
          ),
        );
      }
      else if(remoteUids.length == 2) {
        return Column(
          children: [
            Expanded(child: RtcRemoteView.SurfaceView(uid: remoteUids[0], channelId: widget.channelName,)),
            Expanded(child: RtcRemoteView.SurfaceView(uid: remoteUids[1], channelId: widget.channelName,)),
          ],
        );
      } else {
        return GridView.builder(
          gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
            maxCrossAxisExtent: 200,
            childAspectRatio: 11/20,
            crossAxisSpacing: 5,
            mainAxisSpacing: 10,
          ),
          itemCount: remoteUids.length,
          itemBuilder: (context, i) {
            return Container(
              alignment: Alignment.center,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.amber,
              ),
              child: RtcRemoteView.SurfaceView(uid: remoteUids[i], channelId: widget.channelName),
            );
          },
        );
      }
    } else {
      return const Text('Waiting for other users');
    }
  }

}
